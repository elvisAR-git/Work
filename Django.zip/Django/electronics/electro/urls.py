from django.urls import path

from .views import index, vendors, account, products, edit_product, edit_vendor, delete_product, delete_vendor

app_name = "electro"


urlpatterns = [
    path('', index, name="home"),
    path('vendors', vendors, name="vendors"),
    path('account', account, name="account"),
    path('products', products, name="products"),
    path("edit/products/<int:id>/", edit_product, name="editproduct"),
    path("edit/vendors/<int:id>/", edit_vendor, name="editvendor"),
    path("delete/vendors/<int:id>/", delete_vendor, name="deletevendor"),
    path("delete/products/<int:id>/", delete_product, name="deleteproducts")
]
