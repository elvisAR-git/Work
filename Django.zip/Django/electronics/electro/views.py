# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
from .forms import *

# Create your views here.


def index(request):
    return render(request, "index.html")


def vendors(request):
    if request.method == "GET":
        vendors = Vendor.objects.all()
        context = {
            "form": VendorForm,
            "productForm": ProductForm,
            "vendors": vendors
        }
        return render(request, "vendors.html", context)
    elif request.method == "POST":
        form = VendorForm(request.POST)
        if form.is_valid():
            try:
                vendor = Vendor.objects.get(pk=int(request.POST['id']))

                vendor.vendor_name = request.POST['vendor_name']

                vendor.vendor_description = request.POST['vendor_description']

                vendor.vendor_image_url = request.POST['vendor_image_url']

                vendor.save()
                return redirect("/vendors")
            except:
                vendor = Vendor(
                    vendor_name=request.POST['vendor_name'],
                    vendor_description=request.POST['vendor_description'],
                    no_of_products=0,
                    vendor_image_url=request.POST['vendor_image_url']
                )
                vendor.save()

            return redirect("/vendors")


def products(request):
    if request.method == "GET":
        Products = Product.objects.all()
        context = {
            "form": ProductForm,
            "products": Products
        }
        return render(request, "products.html", context)
    elif request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            try:
                product = Product.objects.filter(
                    pk=int(request.POST['id']))[0]

                product.product_name = request.POST['product_name']
                product.stock = request.POST['stock']
                product.product_price = request.POST['product_price']
                product.product_discount = request.POST['product_discount']
                product.product_description = request.POST['product_description']
                product.product_rating = request.POST['product_rating']
                product.product_image_url = request.POST['product_image_url']
                product.vendor = Vendor.objects.get(id=request.POST['vendor'])
                product.save()
                print(product)

                return redirect("/products")
            except:
                print("exerted")
                product = Product(
                    product_name=request.POST['product_name'],
                    stock=request.POST['stock'],
                    product_price=request.POST['product_price'],
                    product_discount=request.POST['product_discount'],
                    product_description=request.POST['product_description'],
                    product_rating=request.POST['product_rating'],
                    product_image_url=request.POST['product_image_url'],
                    vendor=Vendor.objects.get(id=request.POST['vendor'])
                )
                Vendor.objects.get(
                    id=request.POST['vendor']).no_of_products += 1
                Vendor.objects.get(id=request.POST['vendor']).save()

                product.save()

                return redirect("/products")


def account(request):
    return render(request, "account.html")


def edit_product(request, id):

    product = Product.objects.get(pk=id)
    form = ProductForm(initial={
        'product_name': product.product_name,
        'product_price': product.product_price,
        'stock': product.stock,
        'product_discount': product.product_discount,
        'product_description': product.product_description,
        'product_rating': product.product_rating,
        'product_image_url': product.product_image_url,
        'vendor': product.vendor
    })
    return render(request, "editproduct.html", context={"product": product, "form": form})


def edit_vendor(request, id):
    vendor = Vendor.objects.get(pk=id)

    form = VendorForm(
        initial={
            "vendor_name": vendor.vendor_name,
            "vendor_image_url": vendor.vendor_image_url,
            "vendor_description": vendor.vendor_description,
        }
    )

    return render(request, "editvendor.html", context={"vendor": vendor, "form": form})


def delete_vendor(request, id):
    Vendor.objects.get(pk=id).delete()
    return redirect("/vendors")


def delete_product(request, id):
    Product.objects.get(pk=id).delete()
    return redirect("/products")
