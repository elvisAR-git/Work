from django.forms import ModelForm
import django.forms as forms
from django.db import models as db_models
from .models import *


class VendorForm(forms.ModelForm):
    class Meta:
        model = Vendor
        fields = [
            "vendor_name",
            "vendor_image_url",
            "vendor_description"
        ]
        widgets = {
            "vendor_name": forms.TextInput(
                attrs={"class": "form-control",
                       "placeholder": "Enter The vendor name"}
            ),
            "vendor_image_url": forms.URLInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter image Url"
                }
            ),
            "vendor_description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter Description"
                }
            )
        }


class ProductForm(ModelForm):
    class Meta:
        model = Product
        fields = [
            "product_name",
            "stock",
            "product_price",
            "product_discount",
            "product_description",
            "product_rating",
            "product_image_url",
            "vendor",
        ]
        widgets = {
            "product_name": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter the product name"
                }
            ),
            "stock": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter number of items in stock"
                }
            ),
            "product_price": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter price"
                }
            ),
            "product_discount": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter discount value"
                }
            ),
            "product_description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter the product description"
                }
            ),
            "product_rating": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter the product rating(1-5)"
                }
            ),
            "product_image_url": forms.URLInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter the image url"
                }
            ),
            "vendor": forms.Select(
                attrs={
                    "class": "form-control",
                }
            )

        }
