# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django.contrib.auth.models import User

# Create your models here.


class Vendor(models.Model):
    vendor_name = models.CharField(max_length=50)
    vendor_description = models.TextField(default="No description")
    vendor_image_url = models.URLField()
    time = models.DateTimeField(auto_now_add=True)
    no_of_products = models.IntegerField()

    def __str__(self):
        return self.vendor_name


class Product(models.Model):
    product_name = models.CharField(max_length=56, default="")
    time = models.DateTimeField(auto_now_add=True)
    stock = models.IntegerField()
    product_price = models.IntegerField(default=0)
    product_discount = models.IntegerField(default=0)
    product_description = models.TextField(default="No description")
    product_rating = models.IntegerField(default=0)
    product_image_url = models.URLField(null=True)
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE)

    def __str__(self):
        return self.product_name

